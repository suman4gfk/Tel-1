package com.infytel.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FriendsFamilyDTO {
    private long phoneNumber;
    private long friendFamily;
}
